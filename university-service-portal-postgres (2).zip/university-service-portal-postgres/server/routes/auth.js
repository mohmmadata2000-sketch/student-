const express = require('express');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../db');

const router = express.Router();
const hash = value => crypto.createHash('sha256').update(value).digest('hex');

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });

    const result = await db.query('SELECT id, full_name, student_number, email, password_hash, role FROM users WHERE LOWER(email)=LOWER($1)', [email.trim()]);
    const user = result.rows[0];

    if (!user || hash(password) !== user.password_hash) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const token = jwt.sign(
      { id: user.id, name: user.full_name, role: user.role, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.json({
      token,
      user: { id: user.id, full_name: user.full_name, student_number: user.student_number, email: user.email, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/register', async (req, res) => {
  try {
    const { full_name, student_number, email, password } = req.body;
    if (!full_name || !student_number || !email || !password) {
      return res.status(400).json({ message: 'Please fill all fields.' });
    }
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters.' });

    const result = await db.query(
      `INSERT INTO users(full_name,student_number,email,password_hash)
       VALUES($1,$2,$3,$4) RETURNING id`,
      [full_name.trim(), student_number.trim(), email.trim().toLowerCase(), hash(password)]
    );
    res.status(201).json({ message: 'Account created successfully.', id: result.rows[0].id });
  } catch (err) {
    res.status(400).json({ message: err.code === '23505' ? 'Email or student number already exists.' : err.message });
  }
});

module.exports = router;
