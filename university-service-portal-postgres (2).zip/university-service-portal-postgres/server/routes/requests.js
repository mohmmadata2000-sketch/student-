const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../auth');

const router = express.Router();

router.get('/types', requireAuth, async (req, res) => {
  const result = await db.query('SELECT id,name,description FROM service_types ORDER BY id');
  res.json(result.rows);
});

router.post('/', requireAuth, requireRole('student'), async (req, res) => {
  try {
    const { service_type_id, title, details } = req.body;
    if (!service_type_id || !title) return res.status(400).json({ message: 'Service type and title are required.' });

    const result = await db.query(
      `INSERT INTO requests(user_id,service_type_id,title,details)
       VALUES($1,$2,$3,$4) RETURNING id`,
      [req.user.id, service_type_id, title.trim(), details || null]
    );
    res.status(201).json({ message: 'Request submitted successfully.', id: result.rows[0].id });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.get('/mine', requireAuth, requireRole('student'), async (req, res) => {
  const result = await db.query(
    `SELECT r.id,r.title,r.details,r.status,r.staff_note,r.created_at,r.updated_at,
            s.name AS service_name
     FROM requests r
     JOIN service_types s ON s.id=r.service_type_id
     WHERE r.user_id=$1 ORDER BY r.created_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

router.get('/all', requireAuth, requireRole('staff'), async (req, res) => {
  const result = await db.query(
    `SELECT r.id,r.title,r.details,r.status,r.staff_note,r.created_at,r.updated_at,
            s.name AS service_name,u.full_name,u.email,u.student_number
     FROM requests r
     JOIN service_types s ON s.id=r.service_type_id
     JOIN users u ON u.id=r.user_id
     ORDER BY r.created_at DESC`
  );
  res.json(result.rows);
});

router.patch('/:id/status', requireAuth, requireRole('staff'), async (req, res) => {
  try {
    const { status, staff_note } = req.body;
    const allowed = ['Pending','Under Review','Approved','Rejected'];
    if (!allowed.includes(status)) return res.status(400).json({ message: 'Invalid status.' });

    const result = await db.query(
      `UPDATE requests SET status=$1,staff_note=$2,updated_at=NOW()
       WHERE id=$3 RETURNING user_id`,
      [status, staff_note || null, req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ message: 'Request not found.' });

    await db.query(
      `INSERT INTO notifications(user_id,request_id,title,body)
       VALUES($1,$2,$3,$4)`,
      [result.rows[0].user_id, req.params.id, 'Request updated', `Your request is now "${status}".`]
    );

    res.json({ message: 'Request updated successfully.' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.get('/:id/messages', requireAuth, async (req, res) => {
  const result = await db.query(
    `SELECT m.id,m.message,m.created_at,u.full_name
     FROM messages m JOIN users u ON u.id=m.sender_id
     WHERE m.request_id=$1 ORDER BY m.created_at`,
    [req.params.id]
  );
  res.json(result.rows);
});

router.post('/:id/messages', requireAuth, async (req, res) => {
  try {
    if (!req.body.message?.trim()) return res.status(400).json({ message: 'Message is required.' });
    await db.query(
      'INSERT INTO messages(request_id,sender_id,message) VALUES($1,$2,$3)',
      [req.params.id, req.user.id, req.body.message.trim()]
    );
    res.status(201).json({ message: 'Message sent.' });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
