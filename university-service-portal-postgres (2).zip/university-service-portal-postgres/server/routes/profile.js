const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');
const router = express.Router();

router.get('/me', requireAuth, async (req,res) => {
  const result = await db.query(
    'SELECT id,full_name,student_number,email,role,created_at FROM users WHERE id=$1',
    [req.user.id]
  );
  res.json(result.rows[0]);
});

router.get('/notifications', requireAuth, async (req,res) => {
  const result = await db.query(
    `SELECT id,title,body,is_read,created_at,request_id
     FROM notifications WHERE user_id=$1 ORDER BY created_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

module.exports = router;
