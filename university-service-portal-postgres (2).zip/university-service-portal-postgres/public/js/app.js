const API='/api';
const getToken=()=>localStorage.getItem('token');
const headers=()=>({'Content-Type':'application/json','Authorization':'Bearer '+getToken()});
function logout(){localStorage.clear();location.href='/login.html'}
function requireLogin(){if(!getToken()){location.href='/login.html';return false}return true}
async function api(url, options={}){const r=await fetch(API+url,{...options,headers:{...headers(),...(options.headers||{})}});let data={};try{data=await r.json()}catch{}if(r.status===401){logout();return null}if(!r.ok)throw new Error(data.message||'Request failed');return data}

function setupLogin(){
  document.getElementById('loginForm').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=document.getElementById('message'); msg.textContent='Signing in...';
    try{
      const data=await api('/auth/login',{method:'POST',body:JSON.stringify({email:email.value,password:password.value})});
      localStorage.setItem('token',data.token); localStorage.setItem('user',JSON.stringify(data.user));
      location.href=data.user.role==='staff'?'/staff.html':'/student.html';
    }catch(err){msg.textContent=err.message}
  });
}
function setupRegister(){
  document.getElementById('registerForm').addEventListener('submit',async e=>{
    e.preventDefault(); const msg=document.getElementById('message'); msg.textContent='Creating account...';
    try{await api('/auth/register',{method:'POST',body:JSON.stringify({full_name:full_name.value,student_number:student_number.value,email:email.value,password:password.value})});msg.textContent='Account created. Redirecting...';setTimeout(()=>location.href='/login.html',700)}
    catch(err){msg.textContent=err.message}
  });
}
function statusClass(s){return s.replace(' ','').replace('UnderReview','Under')}
function requestHtml(r,staff=false){
  return `<div class="request"><div class="request-head"><strong>#${r.id} — ${escapeHtml(r.title)}</strong><span class="status ${statusClass(r.status)}">${r.status}</span></div>
  <p><b>${escapeHtml(r.service_name)}</b>${staff?` · ${escapeHtml(r.full_name)} (${escapeHtml(r.student_number||r.email)})`:''}</p>
  <p>${escapeHtml(r.details||'No details provided.')}</p>
  ${r.staff_note?`<p><b>Staff note:</b> ${escapeHtml(r.staff_note)}</p>`:''}
  ${staff?`<div style="display:flex;gap:8px;align-items:center"><select onchange="changeStatus(${r.id},this.value)"><option value="">Change status...</option><option>Pending</option><option>Under Review</option><option>Approved</option><option>Rejected</option></select></div>`:''}
  <small class="muted">${new Date(r.created_at).toLocaleString()}</small></div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

async function loadStudent(){
  if(!requireLogin())return;
  const u=JSON.parse(localStorage.getItem('user')||'{}'); document.getElementById('userName').textContent=u.full_name||'';document.getElementById('profile').textContent=u.student_number||u.email||'';
  try{
    const types=await api('/requests/types');document.getElementById('service_type_id').innerHTML=types.map(x=>`<option value="${x.id}">${escapeHtml(x.name)}</option>`).join('');
    const rows=await api('/requests/mine');document.getElementById('requests').innerHTML=rows.length?rows.map(r=>requestHtml(r)).join(''):'<div class="empty">No requests yet.</div>';
    const notes=await api('/profile/notifications');document.getElementById('notifications').innerHTML=notes.length?notes.slice(0,6).map(n=>`<div class="request"><strong>${escapeHtml(n.title)}</strong><p>${escapeHtml(n.body)}</p><small class="muted">${new Date(n.created_at).toLocaleString()}</small></div>`).join(''):'<p class="muted">No notifications yet.</p>';
  }catch(e){document.getElementById('requests').innerHTML=`<p class="message">${e.message}</p>`}
  document.getElementById('requestForm').onsubmit=async e=>{e.preventDefault();const m=document.getElementById('requestMessage');try{await api('/requests',{method:'POST',body:JSON.stringify({service_type_id:service_type_id.value,title:title.value,details:details.value})});m.textContent='Request submitted successfully.';e.target.reset();await loadStudent()}catch(err){m.textContent=err.message}};
}
async function loadStaff(){
  if(!requireLogin())return;
  const u=JSON.parse(localStorage.getItem('user')||'{}');document.getElementById('userName').textContent=u.full_name||'';
  try{const rows=await api('/requests/all');document.getElementById('total').textContent=rows.length;document.getElementById('pending').textContent=rows.filter(x=>x.status==='Pending').length;document.getElementById('review').textContent=rows.filter(x=>x.status==='Under Review').length;document.getElementById('done').textContent=rows.filter(x=>x.status==='Approved'||x.status==='Rejected').length;document.getElementById('requests').innerHTML=rows.length?rows.map(r=>requestHtml(r,true)).join(''):'<div class="empty">No requests yet.</div>'}catch(e){document.getElementById('requests').innerHTML=`<p class="message">${e.message}</p>`}
}
async function changeStatus(id,status){if(!status)return;try{await api('/requests/'+id+'/status',{method:'PATCH',body:JSON.stringify({status})});await loadStaff()}catch(e){alert(e.message)}}
